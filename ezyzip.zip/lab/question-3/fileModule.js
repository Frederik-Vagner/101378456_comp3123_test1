var fs = require('fs');

    function createFilesnFolders(){
        
        fs.mkdir('logs', { recursive: true }, (err) => {
            if (err) {
                throw err;
            }
           console.log('Folder is created')
        });
    fs.writeFile('logs/log1', 'console.log("hello")',function(err){
        if (err) throw err;
  console.log('File is created successfully.');
    })
    fs.writeFile('logs/log2', 'console.log("hello")',function(err){
        if (err) throw err;
  console.log('File is created successfully.');
    })
    fs.writeFile('logs/log3', 'console.log("hello")',function(err){
        if (err) throw err;
  console.log('File is created successfully.');
    })
    fs.writeFile('logs/log4', 'console.log("hello")',function(err){
        if (err) throw err;
  console.log('File is created successfully.');
    })
    fs.writeFile('logs/log5', 'console.log("hello")',function(err){
        if (err) throw err;
  console.log('File is created successfully.');
    })
    fs.writeFile('logs/log6', 'console.log("hello")',function(err){
        if (err) throw err;
  console.log('File is created successfully.');
    })
    fs.writeFile('logs/log7', 'console.log("hello")',function(err){
        if (err) throw err;
  console.log('File is created successfully.');
    })
    fs.writeFile('logs/log8', 'console.log("hello")',function(err){
        if (err) throw err;
  console.log('File is created successfully.');
    })
    fs.writeFile('logs/log9', 'console.log("hello")',function(err){
        if (err) throw err;
  console.log('File is created successfully.');
    })
    fs.writeFile('logs/log10', 'console.log("hello")',function(err){
        if (err) throw err;
  console.log('File is created successfully.');
    })
    fs.rmdir('logs', { recursive: true }, (err) => {
        if (err) {
            throw err;
        }
       console.log('Folder is deleted and files are deleted')
    });
    }

    createFilesnFolders()
    
    
    