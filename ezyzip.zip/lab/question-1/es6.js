

const mixedArray = ['PIZZA', 10, true, 25, false, 'Wings'];

const result = mixedArray.filter(word => word.length < 8);

console.log(result);

